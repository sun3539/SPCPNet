import argparse
import logging
import math
import os
import os.path as osp
import time

import torch
from torch.utils.data.distributed import DistributedSampler

from basicsr.data import create_dataloader, create_dataset
from basicsr.models import create_model
from basicsr.utils import (MessageLogger, check_resume, get_env_info,
                           get_root_logger, get_time_str, init_tb_logger,
                           make_exp_dirs, set_random_seed)
from basicsr.utils.dist_util import get_dist_info, init_dist
from basicsr.utils.options import dict2str, parse


def parse_options(is_train=True):
    parser = argparse.ArgumentParser()
    parser.add_argument('-opt', type=str, required=True, help='Path to option YAML file.')
    parser.add_argument('--launcher', choices=['none', 'pytorch', 'slurm'], default='none')
    parser.add_argument('--local_rank', type=int, default=0)
    args = parser.parse_args()

    opt = parse(args.opt, is_train=is_train)

    if args.launcher == 'none':
        opt['dist'] = False
        rank, world_size = 0, 1
        print('Disable distributed.', flush=True)
    else:
        opt['dist'] = True
        init_dist(args.launcher, **opt['dist_params'])
        rank, world_size = get_dist_info()

    opt['rank'] = rank
    opt['world_size'] = world_size

    seed = opt.get('manual_seed', None)
    if seed is None:
        seed = 0
        opt['manual_seed'] = seed
    set_random_seed(seed + rank)

    return opt


def init_loggers(opt):
    log_file = osp.join(opt['path']['log'], f"train_{opt['name']}_{get_time_str()}.log")
    logger = get_root_logger(logger_name='basicsr', log_level=logging.INFO, log_file=log_file)
    logger.info(get_env_info())
    logger.info(dict2str(opt))

    tb_logger = None
    if opt['logger'].get('use_tb_logger', False):
        tb_logger = init_tb_logger(log_dir=osp.join(opt['path']['experiments_root'], 'tb_logger', opt['name']))
    return logger, tb_logger


def create_train_val_loaders(opt, logger):
    train_loader = None
    train_sampler = None
    val_loader = None
    total_epochs = 0
    total_iters = opt['train']['total_iter']

    for phase, dataset_opt in opt['datasets'].items():
        if phase == 'train':
            train_set = create_dataset(dataset_opt)
            if opt['dist']:
                train_sampler = DistributedSampler(
                    train_set,
                    num_replicas=opt['world_size'],
                    rank=opt['rank'],
                    shuffle=dataset_opt.get('use_shuffle', True),
                    drop_last=True,
                )
            train_loader = create_dataloader(
                train_set,
                dataset_opt,
                num_gpu=opt['num_gpu'],
                dist=opt['dist'],
                sampler=train_sampler,
                seed=opt['manual_seed'],
            )
            num_iter_per_epoch = len(train_loader)
            total_epochs = math.ceil(total_iters / num_iter_per_epoch)
            logger.info(
                f'Number of train images: {len(train_set)} | '
                f'iters/epoch: {num_iter_per_epoch} | total epochs: {total_epochs}, total iters: {total_iters}.')
        elif phase == 'val':
            val_set = create_dataset(dataset_opt)
            val_loader = create_dataloader(
                val_set,
                dataset_opt,
                num_gpu=opt['num_gpu'],
                dist=opt['dist'],
                sampler=None,
                seed=opt['manual_seed'],
            )
            logger.info(f'Number of val images in {dataset_opt["name"]}: {len(val_set)}')

    return train_loader, train_sampler, val_loader, total_epochs, total_iters


def load_resume_state(opt):
    resume_state_path = opt['path'].get('resume_state')
    if resume_state_path is None:
        return None
    device = torch.cuda.current_device() if torch.cuda.is_available() else 'cpu'
    resume_state = torch.load(resume_state_path, map_location=lambda storage, loc: storage.cuda(device) if torch.cuda.is_available() else storage)
    check_resume(opt, resume_state['iter'])
    return resume_state


def main():
    opt = parse_options(is_train=True)
    torch.backends.cudnn.benchmark = True

    resume_state = load_resume_state(opt)
    if resume_state is None:
        make_exp_dirs(opt)
    logger, tb_logger = init_loggers(opt)

    train_loader, train_sampler, val_loader, total_epochs, total_iters = create_train_val_loaders(opt, logger)
    model = create_model(opt)

    if resume_state is not None:
        model.resume_training(resume_state)
        start_epoch = resume_state['epoch']
        current_iter = resume_state['iter']
        logger.info(f'Resuming training from epoch: {start_epoch}, iter: {current_iter}.')
    else:
        start_epoch = 0
        current_iter = 0

    msg_logger = MessageLogger(opt, current_iter, tb_logger)
    data_time, iter_time = time.time(), time.time()
    logger.info('Start training.')

    for epoch in range(start_epoch, total_epochs + 1):
        if train_sampler is not None:
            train_sampler.set_epoch(epoch)

        for train_data in train_loader:
            data_time = time.time() - data_time
            current_iter += 1
            if current_iter > total_iters:
                break

            model.update_learning_rate(current_iter, warmup_iter=opt['train'].get('warmup_iter', -1))
            if hasattr(model, 'set_training_progress'):
                model.set_training_progress(epoch=epoch, total_epochs=total_epochs, current_iter=current_iter, total_iters=total_iters)
            model.feed_train_data(train_data)
            model.optimize_parameters(current_iter)
            iter_time = time.time() - iter_time

            if current_iter % opt['logger']['print_freq'] == 0:
                log_vars = {'epoch': epoch, 'iter': current_iter, 'lrs': model.get_current_learning_rate(), 'time': iter_time, 'data_time': data_time}
                log_vars.update(model.get_current_log())
                msg_logger(log_vars)

            if val_loader is not None and current_iter % opt['val']['val_freq'] == 0:
                logger.info('Running validation.')
                model.validation(
                    val_loader,
                    current_iter,
                    tb_logger,
                    save_img=opt['val'].get('save_img', False),
                    rgb2bgr=opt['val'].get('rgb2bgr', True),
                    use_image=opt['val'].get('use_image', False),
                )

            if current_iter % opt['logger']['save_checkpoint_freq'] == 0:
                logger.info('Saving models and training states.')
                model.save(epoch, current_iter)

            data_time = time.time()
            iter_time = time.time()

        if current_iter > total_iters:
            break

    logger.info('Saving latest model.')
    model.save(epoch, -1)
    if tb_logger is not None:
        tb_logger.close()
    logger.info('End of training.')


if __name__ == '__main__':
    main()
