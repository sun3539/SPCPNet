from collections import OrderedDict
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from basicsr.models.archs.prior_utils import (
    AdaptiveMultiScaleSobelPrior,
    ColorInvariantAdaptiveMultiScaleSobelPrior,
    MultiInvariantPrior,
    SobelPrior,
)

class FeatureChannelNorm(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(1, dim, 1, 1))
        self.bias = nn.Parameter(torch.zeros(1, dim, 1, 1))

    def forward(self, x):
        mu = x.mean(dim=1, keepdim=True)
        sigma = x.var(dim=1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5) * self.weight + self.bias


class AppearanceIntraAttention(nn.Module):

    def __init__(self, dim, num_heads=1):
        super().__init__()
        self.num_heads = num_heads
        self.to_qkv = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=False)
        self.rescale = nn.Parameter(torch.ones(num_heads, 1, 1))
        self.proj = nn.Conv2d(dim, dim, kernel_size=1, bias=True)
        self.pos_emb = nn.Sequential(
            nn.Conv2d(dim, dim, 3, 1, 1, bias=False, groups=dim),
            nn.GELU(),
            nn.Conv2d(dim, dim, 3, 1, 1, bias=False, groups=dim),
        )

    def forward(self, x):
        b, c, h, w = x.shape
        qkv = self.to_qkv(x)
        q, k, v = qkv.chunk(3, dim=1)
        out_p = self.pos_emb(v)

        q = q.view(b, self.num_heads, c // self.num_heads, h * w)
        k = k.view(b, self.num_heads, c // self.num_heads, h * w)
        v = v.view(b, self.num_heads, c // self.num_heads, h * w)

        q = F.normalize(q, dim=-1, p=2)
        k = F.normalize(k, dim=-1, p=2)

        attn = (k @ q.transpose(-2, -1)) * self.rescale
        attn = attn.softmax(dim=-1)

        out = attn @ v
        out = out.view(b, c, h, w)
        out = self.proj(out) + out_p
        return out


class PriorCalibratedCrossAttention(nn.Module):

    def __init__(self, dim, num_heads=1):
        super().__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.q = nn.Conv2d(dim, dim, kernel_size=1, bias=False)
        self.q_dwconv = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim, bias=False)

        self.kv = nn.Conv2d(dim, dim * 2, kernel_size=1, bias=False)
        self.kv_dwconv = nn.Conv2d(dim * 2, dim * 2, kernel_size=3, stride=1, padding=1, groups=dim * 2, bias=False)

        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=False)

    def forward(self, x, prior_feat):
        b, c, h, w = x.shape

        q = self.q_dwconv(self.q(x))
        q = q.view(b, self.num_heads, c // self.num_heads, h * w)

        kv = self.kv_dwconv(self.kv(prior_feat))
        k, v = kv.chunk(2, dim=1)
        k = k.view(b, self.num_heads, c // self.num_heads, h * w)
        v = v.view(b, self.num_heads, c // self.num_heads, h * w)

        q = F.normalize(q, dim=-1)
        k = F.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = attn @ v
        out = out.view(b, c, h, w)
        return self.project_out(out)


class RefinementFeedForward(nn.Module):
    def __init__(self, dim, mult=4):
        super().__init__()
        hidden_dim = int(dim * mult)
        self.net = nn.Sequential(
            nn.Conv2d(dim, hidden_dim, 1, 1, bias=False),
            nn.GELU(),
            nn.Conv2d(hidden_dim, hidden_dim, 3, 1, 1, groups=hidden_dim, bias=False),
            nn.GELU(),
            nn.Conv2d(hidden_dim, dim, 1, 1, bias=False),
        )

    def forward(self, x):
        return self.net(x)


class StructureReliabilityGate(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.gate = nn.Sequential(
            nn.Conv2d(dim * 2, dim, kernel_size=1, stride=1, padding=0, bias=True),
            nn.GELU(),
            nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim, bias=True),
            nn.Sigmoid(),
        )

    def forward(self, x, prior_feat):
        return self.gate(torch.cat([x, prior_feat], dim=1))


class StructurePriorInjection(nn.Module):


    def __init__(self, s_channels, dim):
        super().__init__()
        self.s_channels = s_channels
        self.proj = nn.Conv2d(s_channels, dim, kernel_size=3, stride=1, padding=1)
        self.norm = FeatureChannelNorm(dim)

    def forward(self, s):
        return self.norm(self.proj(s))


class PerturbationConsistentSubBlock(nn.Module):

    def __init__(self, dim, num_heads=1):
        super().__init__()
        self.self_attn = AppearanceIntraAttention(dim, num_heads)

        self.norm_cross = FeatureChannelNorm(dim)
        self.cross_attn = PriorCalibratedCrossAttention(dim, num_heads)
        self.prior_gate = StructureReliabilityGate(dim)

        self.norm_ffn = FeatureChannelNorm(dim)
        self.ffn = RefinementFeedForward(dim)

    def forward(self, x, prior_feat):
        x = self.self_attn(x) + x

        x_norm = self.norm_cross(x)
        cross_delta = self.cross_attn(x_norm, prior_feat)
        cross_gate = self.prior_gate(x_norm, prior_feat)
        x = cross_delta * cross_gate + x

        x = self.ffn(self.norm_ffn(x)) + x
        return x


class PerturbationConsistentAttentionBlock(nn.Module):

    def __init__(self, dim, num_blocks=2, num_heads=1):
        super().__init__()
        self.blocks = nn.ModuleList([
            PerturbationConsistentSubBlock(dim, num_heads) for _ in range(num_blocks)
        ])

    def forward(self, x, prior_feat):
        for blk in self.blocks:
            x = blk(x, prior_feat)
        return x


class SpectralDetailRefinement(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.freq_dw = nn.Conv2d(dim * 2, dim * 2, kernel_size=3, stride=1, padding=1, groups=dim * 2, bias=False)
        self.freq_pw = nn.Conv2d(dim * 2, dim * 2, kernel_size=1, stride=1, padding=0, bias=True)
        self.out_proj = nn.Conv2d(dim, dim, kernel_size=1, stride=1, padding=0, bias=False)
        self.spatial_gate = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=1, stride=1, padding=0, bias=True),
            nn.Sigmoid(),
        )
        self.res_scale = nn.Parameter(torch.zeros(1))

    def forward(self, x):
        h, w = x.shape[-2:]
        freq = torch.fft.rfft2(x, dim=(-2, -1), norm='ortho')
        freq_feat = torch.cat([freq.real, freq.imag], dim=1)
        freq_delta = self.freq_pw(F.gelu(self.freq_dw(freq_feat)))
        delta_real, delta_imag = torch.chunk(freq_delta, 2, dim=1)

        delta_freq = torch.complex(delta_real, delta_imag)
        delta = torch.fft.irfft2(delta_freq, s=(h, w), dim=(-2, -1), norm='ortho')

        gate = self.spatial_gate(x)
        scale = torch.tanh(self.res_scale)
        return x + scale * self.out_proj(delta) * gate



def _match_prior_channels(s, target_channels):
    if s.shape[1] == target_channels:
        return s
    if s.shape[1] > target_channels:
        return s[:, :target_channels, :, :]

    repeat_factor = math.ceil(target_channels / s.shape[1])
    s = s.repeat(1, repeat_factor, 1, 1)
    return s[:, :target_channels, :, :]


class SPCPNet(nn.Module):

    def __init__(self,
                 en_feature_num=48,
                 en_inter_num=32,
                 de_feature_num=64,
                 de_inter_num=32,
                 sam_number=2,
                 training=True,
                 use_online_prior=True,
                 prior_type='ci_masp',
                 prior_invariants=('W', 'H', 'C'),
                 prior_k=3,
                 prior_scale=0.9,
                 prior_sobel_scales=(1.0, 0.5, 0.25),
                 prior_sobel_init_bias=8.0,
                 prior_ci_fusion_init_bias=8.0,
                 decoder_freq_levels=(1, 2)):
        super(SPCPNet, self).__init__()
        if isinstance(prior_invariants, str):
            prior_invariants = [prior_invariants]

        self.use_online_prior = use_online_prior
        prior_type = str(prior_type).lower()
        if prior_type in ('sobel', 'sobel_prior', 'sobel_gray'):
            self.prior_extractor = SobelPrior(clamp_output=True)
        elif prior_type in ('adaptive_multiscale_sobel', 'masp', 'multi_scale_sobel', 'multiscale_sobel'):
            self.prior_extractor = AdaptiveMultiScaleSobelPrior(
                scales=prior_sobel_scales,
                init_bias=prior_sobel_init_bias,
                clamp_output=True,
            )
        elif prior_type in ('ci_masp', 'color_invariant_masp', 'color_invariant_adaptive_multiscale_sobel', 'ci_sobel'):
            self.prior_extractor = ColorInvariantAdaptiveMultiScaleSobelPrior(
                scales=prior_sobel_scales,
                init_bias=prior_sobel_init_bias,
                ci_fusion_init_bias=prior_ci_fusion_init_bias,
                clamp_output=True,
            )
        elif prior_type in ('multi_invariant', 'ciconv', 'ci', 'original'):
            self.prior_extractor = MultiInvariantPrior(
                invariants=prior_invariants,
                k=prior_k,
                scale=prior_scale,
                clamp_output=True,
            )
        else:
            raise ValueError(f'Unsupported prior_type: {prior_type}')
        self.prior_channels = self.prior_extractor.out_channels

        self.encoder = Encoder(
            feature_num=en_feature_num,
            inter_num=en_inter_num,
            sam_number=sam_number,
            s_channels=self.prior_channels,
        )
        self.decoder = Decoder(
            en_num=en_feature_num,
            feature_num=de_feature_num,
            inter_num=de_inter_num,
            sam_number=sam_number,
            s_channels=self.prior_channels,
            freq_levels=decoder_freq_levels,
        )

    def extract_prior(self, x):
        return self.prior_extractor(x)

    @staticmethod
    def _convert_legacy_state_dict(state_dict):
        converted = OrderedDict()
        for key, value in state_dict.items():
            new_key = key
            new_key = new_key.replace('.sgab.s_conv.', '.spim.proj.')
            new_key = new_key.replace('.sgab.s_norm.', '.spim.norm.')
            new_key = new_key.replace('.sgab.blocks.', '.cpgb.pcab.blocks.')
            new_key = new_key.replace('.rdb.', '.cpgb.local_texture.')
            new_key = new_key.replace('.sam_blocks.', '.cpgb.scale_context_blocks.')
            converted[new_key] = value
        return converted

    def load_state_dict(self, state_dict, strict=True, assign=False):
        if any('.sgab.' in k or '.rdb.' in k or '.sam_blocks.' in k for k in state_dict.keys()):
            state_dict = self._convert_legacy_state_dict(state_dict)
        try:
            return super().load_state_dict(state_dict, strict=strict, assign=assign)
        except TypeError:
            # For older PyTorch versions without the assign argument.
            return super().load_state_dict(state_dict, strict=strict)

    def forward(self, x, s=None, guide_x=None, return_prior=False):
        _, _, H, W = x.shape

        guide_source = x if guide_x is None else guide_x

        prior = None
        if guide_x is not None or self.use_online_prior or s is None or return_prior:
            prior = self.extract_prior(guide_source)

        if s is None:
            if prior is None:
                prior = self.extract_prior(guide_source)
            s = prior

        if s.shape[-2:] != (H, W):
            s = F.interpolate(s, size=(H, W), mode='bilinear', align_corners=False)
        s = _match_prior_channels(s, self.prior_channels)

        rate = 2 ** 5
        pad_h = (rate - H % rate) % rate
        pad_w = (rate - W % rate) % rate

        if pad_h != 0 or pad_w != 0:
            x = F.pad(x, (0, pad_w, 0, pad_h), mode='reflect')
            s = F.pad(s, (0, pad_w, 0, pad_h), mode='reflect')

        y_1, y_2, y_3 = self.encoder(x, s)
        out_1, out_2, out_3 = self.decoder(y_1, y_2, y_3, s)

        out_1 = out_1[:, :, :H, :W]
        out_2 = out_2[:, :, :H // 2, :W // 2]
        out_3 = out_3[:, :, :H // 4, :W // 4]

        if return_prior:
            return out_1, out_2, out_3, prior[:, :, :H, :W]
        return out_1, out_2, out_3

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                m.weight.data.normal_(0.0, 0.02)
                if m.bias is not None:
                    m.bias.data.normal_(0.0, 0.02)
            if isinstance(m, nn.ConvTranspose2d):
                m.weight.data.normal_(0.0, 0.02)


class Decoder(nn.Module):
    def __init__(self, en_num, feature_num, inter_num, sam_number, s_channels=3, freq_levels=(1, 2)):
        super(Decoder, self).__init__()
        freq_levels = set(freq_levels)

        self.preconv_3 = conv_relu(4 * en_num, feature_num, 3, padding=1)
        self.decoder_3 = Decoder_Level(
            feature_num,
            inter_num,
            sam_number,
            level=3,
            s_channels=s_channels,
            use_freq_refine=3 in freq_levels,
        )

        self.preconv_2 = conv_relu(2 * en_num + feature_num, feature_num, 3, padding=1)
        self.decoder_2 = Decoder_Level(
            feature_num,
            inter_num,
            sam_number,
            level=2,
            s_channels=s_channels,
            use_freq_refine=2 in freq_levels,
        )

        self.preconv_1 = conv_relu(en_num + feature_num, feature_num, 3, padding=1)
        self.decoder_1 = Decoder_Level(
            feature_num,
            inter_num,
            sam_number,
            level=1,
            s_channels=s_channels,
            use_freq_refine=1 in freq_levels,
        )

    def forward(self, y_1, y_2, y_3, s):
        x_3 = self.preconv_3(y_3)
        out_3, feat_3 = self.decoder_3(x_3, s)

        x_2 = torch.cat([y_2, feat_3], dim=1)
        x_2 = self.preconv_2(x_2)
        out_2, feat_2 = self.decoder_2(x_2, s)

        x_1 = torch.cat([y_1, feat_2], dim=1)
        x_1 = self.preconv_1(x_1)
        out_1 = self.decoder_1(x_1, s, feat=False)

        return out_1, out_2, out_3


class Encoder(nn.Module):
    def __init__(self, feature_num, inter_num, sam_number, s_channels=3):
        super(Encoder, self).__init__()
        self.conv_first = nn.Sequential(
            nn.Conv2d(12, feature_num, kernel_size=5, stride=1, padding=2, bias=True),
            nn.ReLU(inplace=True)
        )
        self.encoder_1 = Encoder_Level(feature_num, inter_num, level=1, sam_number=sam_number, s_channels=s_channels)
        self.encoder_2 = Encoder_Level(2 * feature_num, inter_num, level=2, sam_number=sam_number, s_channels=s_channels)
        self.encoder_3 = Encoder_Level(4 * feature_num, inter_num, level=3, sam_number=sam_number, s_channels=s_channels)

    def forward(self, x, s):
        x = F.pixel_unshuffle(x, 2)
        x = self.conv_first(x)

        out_feature_1, down_feature_1 = self.encoder_1(x, s)
        out_feature_2, down_feature_2 = self.encoder_2(down_feature_1, s)
        out_feature_3 = self.encoder_3(down_feature_2, s)

        return out_feature_1, out_feature_2, out_feature_3


class ColorStructureConsistencyBlock(nn.Module):
    def __init__(self, feature_num, inter_num, sam_number):
        super().__init__()
        self.local_texture = LocalTextureDenseBlock(
            in_channel=feature_num,
            d_list=(1, 2, 1),
            inter_num=inter_num,
        )
        self.pcab = PerturbationConsistentAttentionBlock(
            dim=feature_num,
            num_blocks=2,
            num_heads=1,
        )
        self.scale_context_blocks = nn.ModuleList([
            MultiScaleContextAggregation(
                in_channel=feature_num,
                d_list=(1, 2, 3, 2, 1),
                inter_num=inter_num,
            )
            for _ in range(sam_number)
        ])

    def forward(self, x, prior_feat):
        x = self.local_texture(x)
        x = self.pcab(x, prior_feat)
        for scale_block in self.scale_context_blocks:
            x = scale_block(x)
        return x


class Encoder_Level(nn.Module):
    def __init__(self, feature_num, inter_num, level, sam_number, s_channels=3):
        super(Encoder_Level, self).__init__()
        self.spim = StructurePriorInjection(s_channels=s_channels, dim=feature_num)
        self.cpgb = ColorStructureConsistencyBlock(feature_num, inter_num, sam_number)
        self.s_channels = s_channels

        if level < 3:
            self.down = nn.Sequential(
                nn.Conv2d(feature_num, 2 * feature_num, kernel_size=3, stride=2, padding=1, bias=True),
                nn.ReLU(inplace=True)
            )

        self.level = level

    def forward(self, x, s):
        scale_factor = 1 / (2 ** self.level)
        s_ = F.interpolate(s, scale_factor=scale_factor, mode='bilinear', align_corners=False)
        s_ = _match_prior_channels(s_, self.s_channels)

        prior_feat = self.spim(s_)
        out_feature = self.cpgb(x, prior_feat)

        if self.level < 3:
            down_feature = self.down(out_feature)
            return out_feature, down_feature
        return out_feature


class Decoder_Level(nn.Module):
    def __init__(self, feature_num, inter_num, sam_number, level, s_channels=3, use_freq_refine=False):
        super(Decoder_Level, self).__init__()
        self.spim = StructurePriorInjection(s_channels=s_channels, dim=feature_num)
        self.cpgb = ColorStructureConsistencyBlock(feature_num, inter_num, sam_number)
        self.s_channels = s_channels

        self.use_freq_refine = use_freq_refine
        if self.use_freq_refine:
            self.freq_refine = SpectralDetailRefinement(feature_num)

        self.conv = conv(in_channel=feature_num, out_channel=12, kernel_size=3, padding=1)
        self.level = level

    def forward(self, x, s, feat=True):
        scale_factor = 1 / (2 ** self.level)
        s_ = F.interpolate(s, scale_factor=scale_factor, mode='bilinear', align_corners=False)
        s_ = _match_prior_channels(s_, self.s_channels)

        prior_feat = self.spim(s_)
        x = self.cpgb(x, prior_feat)

        if self.use_freq_refine:
            x = self.freq_refine(x)

        out = self.conv(x)
        out = F.pixel_shuffle(out, 2)

        if feat:
            feature = F.interpolate(x, scale_factor=2, mode='bilinear')
            return out, feature
        return out

class DenseTextureBlock(nn.Module):
    def __init__(self, in_channel, d_list, inter_num):
        super(DenseTextureBlock, self).__init__()
        self.d_list = d_list
        self.conv_layers = nn.ModuleList()
        c = in_channel
        for i in range(len(d_list)):
            dense_conv = conv_relu(
                in_channel=c,
                out_channel=inter_num,
                kernel_size=3,
                dilation_rate=d_list[i],
                padding=d_list[i]
            )
            self.conv_layers.append(dense_conv)
            c = c + inter_num
        self.conv_post = conv(in_channel=c, out_channel=in_channel, kernel_size=1)

    def forward(self, x):
        t = x
        for conv_layer in self.conv_layers:
            _t = conv_layer(t)
            t = torch.cat([_t, t], dim=1)
        t = self.conv_post(t)
        return t


class MultiScaleContextAggregation(nn.Module):
    """MSCA: pyramid context aggregation with adaptive cross-scale fusion."""

    def __init__(self, in_channel, d_list, inter_num):
        super(MultiScaleContextAggregation, self).__init__()
        self.basic_block = DenseTextureBlock(in_channel=in_channel, d_list=d_list, inter_num=inter_num)
        self.basic_block_2 = DenseTextureBlock(in_channel=in_channel, d_list=d_list, inter_num=inter_num)
        self.basic_block_4 = DenseTextureBlock(in_channel=in_channel, d_list=d_list, inter_num=inter_num)
        self.fusion = CrossScaleAttentionFusion(3 * in_channel)

    def forward(self, x):
        x_0 = x
        x_2 = F.interpolate(x, scale_factor=0.5, mode='bilinear')
        x_4 = F.interpolate(x, scale_factor=0.25, mode='bilinear')

        y_0 = self.basic_block(x_0)
        y_2 = self.basic_block_2(x_2)
        y_4 = self.basic_block_4(x_4)

        y_2 = F.interpolate(y_2, scale_factor=2, mode='bilinear')
        y_4 = F.interpolate(y_4, scale_factor=4, mode='bilinear')

        y = self.fusion(y_0, y_2, y_4)
        y = x + y
        return y


class CrossScaleAttentionFusion(nn.Module):
    def __init__(self, in_chnls, ratio=4):
        super(CrossScaleAttentionFusion, self).__init__()
        self.squeeze = nn.AdaptiveAvgPool2d((1, 1))
        self.compress1 = nn.Conv2d(in_chnls, in_chnls // ratio, 1, 1, 0)
        self.compress2 = nn.Conv2d(in_chnls // ratio, in_chnls // ratio, 1, 1, 0)
        self.excitation = nn.Conv2d(in_chnls // ratio, in_chnls, 1, 1, 0)

    def forward(self, x0, x2, x4):
        out0 = self.squeeze(x0)
        out2 = self.squeeze(x2)
        out4 = self.squeeze(x4)
        out = torch.cat([out0, out2, out4], dim=1)
        out = self.compress1(out)
        out = F.relu(out)
        out = self.compress2(out)
        out = F.relu(out)
        out = self.excitation(out)
        out = torch.sigmoid(out)

        w0, w2, w4 = torch.chunk(out, 3, dim=1)
        x = x0 * w0 + x2 * w2 + x4 * w4
        return x


class LocalTextureDenseBlock(nn.Module):
    """LTDB: local texture dense extraction with residual connection."""

    def __init__(self, in_channel, d_list, inter_num):
        super(LocalTextureDenseBlock, self).__init__()
        self.d_list = d_list
        self.conv_layers = nn.ModuleList()
        c = in_channel
        for i in range(len(d_list)):
            dense_conv = conv_relu(
                in_channel=c,
                out_channel=inter_num,
                kernel_size=3,
                dilation_rate=d_list[i],
                padding=d_list[i]
            )
            self.conv_layers.append(dense_conv)
            c = c + inter_num

        self.conv_post = conv(in_channel=c, out_channel=in_channel, kernel_size=1)

    def forward(self, x):
        t = x
        for conv_layer in self.conv_layers:
            _t = conv_layer(t)
            t = torch.cat([_t, t], dim=1)

        t = self.conv_post(t)
        return t + x


class conv(nn.Module):
    def __init__(self, in_channel, out_channel, kernel_size, dilation_rate=1, padding=0, stride=1):
        super(conv, self).__init__()
        self.conv = nn.Conv2d(
            in_channels=in_channel,
            out_channels=out_channel,
            kernel_size=kernel_size,
            stride=stride,
            padding=padding,
            bias=True,
            dilation=dilation_rate
        )

    def forward(self, x_input):
        out = self.conv(x_input)
        return out


class conv_relu(nn.Module):
    def __init__(self, in_channel, out_channel, kernel_size, dilation_rate=1, padding=0, stride=1):
        super(conv_relu, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(
                in_channels=in_channel,
                out_channels=out_channel,
                kernel_size=kernel_size,
                stride=stride,
                padding=padding,
                bias=True,
                dilation=dilation_rate
            ),
            nn.ReLU(inplace=True)
        )

    def forward(self, x_input):
        out = self.conv(x_input)
        return out