import math
from typing import Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F


eps = 1e-5


def gaussian_basis_filters(scale, device, dtype, k=3):
    scale = torch.as_tensor(scale, device=device, dtype=dtype)
    base = torch.tensor(2.0, device=device, dtype=dtype)
    std = torch.pow(base, scale)

    filter_radius = max(1, int(torch.ceil(k * std + 0.5).item()))
    coords = torch.arange(-filter_radius, filter_radius + 1, device=device, dtype=dtype)
    yy, xx = torch.meshgrid(coords, coords, indexing='ij')

    g = torch.exp(-(xx / std) ** 2 / 2) * torch.exp(-(yy / std) ** 2 / 2)
    g = g / (torch.sum(g) + eps)

    dgdx = -xx / (std ** 3 * 2 * math.pi) * torch.exp(-(xx / std) ** 2 / 2) * torch.exp(-(yy / std) ** 2 / 2)
    dgdx = dgdx / (torch.sum(torch.abs(dgdx)) + eps)

    dgdy = -yy / (std ** 3 * 2 * math.pi) * torch.exp(-(yy / std) ** 2 / 2) * torch.exp(-(xx / std) ** 2 / 2)
    dgdy = dgdy / (torch.sum(torch.abs(dgdy)) + eps)

    basis_filter = torch.stack([g, dgdx, dgdy], dim=0)[:, None, :, :]
    return basis_filter



def E_inv(E, Ex, Ey, El, Elx, Ely, Ell, Ellx, Elly):
    return Ex ** 2 + Ey ** 2 + Elx ** 2 + Ely ** 2 + Ellx ** 2 + Elly ** 2



def W_inv(E, Ex, Ey, El, Elx, Ely, Ell, Ellx, Elly):
    Wx = Ex / (E + eps)
    Wlx = Elx / (E + eps)
    Wllx = Ellx / (E + eps)
    Wy = Ey / (E + eps)
    Wly = Ely / (E + eps)
    Wlly = Elly / (E + eps)
    return Wx ** 2 + Wy ** 2 + Wlx ** 2 + Wly ** 2 + Wllx ** 2 + Wlly ** 2



def C_inv(E, Ex, Ey, El, Elx, Ely, Ell, Ellx, Elly):
    Clx = (Elx * E - El * Ex) / (E ** 2 + eps)
    Cly = (Ely * E - El * Ey) / (E ** 2 + eps)
    Cllx = (Ellx * E - Ell * Ex) / (E ** 2 + eps)
    Clly = (Elly * E - Ell * Ey) / (E ** 2 + eps)
    return Cllx ** 2 + Clly ** 2 + Clx ** 2 + Cly ** 2



def N_inv(E, Ex, Ey, El, Elx, Ely, Ell, Ellx, Elly):
    Nlx = (Elx * E - El * Ex) / (E ** 2 + eps)
    Nly = (Ely * E - El * Ey) / (E ** 2 + eps)
    Nllx = (Ellx * E ** 2 - Ell * Ex * E - 2 * Elx * El * E + 2 * El ** 2 * Ex) / (E ** 3 + eps)
    Nlly = (Elly * E ** 2 - Ell * Ey * E - 2 * Ely * El * E + 2 * El ** 2 * Ey) / (E ** 3 + eps)
    return Nlx ** 2 + Nly ** 2 + Nllx ** 2 + Nlly ** 2



def H_inv(E, Ex, Ey, El, Elx, Ely, Ell, Ellx, Elly):
    Hx = (Ell * Elx - El * Ellx) / (El ** 2 + Ell ** 2 + eps)
    Hy = (Ell * Ely - El * Elly) / (El ** 2 + Ell ** 2 + eps)
    return Hx ** 2 + Hy ** 2


inv_switcher = {
    'E': E_inv,
    'W': W_inv,
    'C': C_inv,
    'N': N_inv,
    'H': H_inv,
}


class CIConv2d(nn.Module):
    def __init__(self, invariant, k=3, scale=0.9, max_scale=2.5):
        super().__init__()
        assert invariant in inv_switcher, 'invalid invariant'
        self.inv_function = inv_switcher[invariant]
        self.k = k
        self.max_scale = float(max_scale)
        self.scale = nn.Parameter(torch.tensor([float(scale)], dtype=torch.float32), requires_grad=True)
        self.register_buffer(
            'gcm',
            torch.tensor(
                [[0.06, 0.63, 0.27], [0.30, 0.04, -0.35], [0.34, -0.60, 0.17]],
                dtype=torch.float32,
            ),
        )

    def bounded_scale(self):
        return self.max_scale * torch.tanh(self.scale / self.max_scale)

    def forward(self, batch):
        if batch.shape[1] != 3:
            raise ValueError(f'CIConv2d expects 3-channel RGB input, but got {batch.shape[1]} channels.')

        in_shape = batch.shape
        flat = batch.view(in_shape[0], in_shape[1], -1)
        gcm = self.gcm.to(device=batch.device, dtype=batch.dtype).unsqueeze(0)
        converted = torch.matmul(gcm, flat)
        converted = converted.view(in_shape[0], 3, in_shape[2], in_shape[3])
        E, El, Ell = torch.split(converted, 1, dim=1)

        w = gaussian_basis_filters(
            scale=self.bounded_scale().squeeze(0),
            device=batch.device,
            dtype=batch.dtype,
            k=self.k,
        )
        padding = w.shape[-1] // 2

        E_out = F.conv2d(E, w, padding=padding)
        El_out = F.conv2d(El, w, padding=padding)
        Ell_out = F.conv2d(Ell, w, padding=padding)

        E, Ex, Ey = torch.split(E_out, 1, dim=1)
        El, Elx, Ely = torch.split(El_out, 1, dim=1)
        Ell, Ellx, Elly = torch.split(Ell_out, 1, dim=1)

        inv_out = self.inv_function(E, Ex, Ey, El, Elx, Ely, Ell, Ellx, Elly)
        inv_out = F.instance_norm(torch.log(inv_out + eps))
        return inv_out


class MultiInvariantPrior(nn.Module):
    def __init__(self, invariants: Sequence[str] = ('W', 'H', 'C'), k=3, scale=0.9, clamp_output=True):
        super().__init__()
        if isinstance(invariants, str):
            invariants = [invariants]
        invariants = list(invariants)
        if len(invariants) == 0:
            raise ValueError('prior invariants must not be empty.')

        self.invariant_names = invariants
        self.extractors = nn.ModuleList([CIConv2d(inv, k=k, scale=scale) for inv in invariants])
        self.clamp_output = clamp_output

    @property
    def out_channels(self):
        return len(self.extractors)

    def forward(self, x):
        prior = torch.cat([extractor(x) for extractor in self.extractors], dim=1)
        if self.clamp_output:
            prior = torch.clamp(prior, 0.0, 1.0)
        return prior

class SobelPrior(nn.Module):
    """Fixed Sobel structure-prior extractor for ablation studies.

    This module replaces the CIConv/MultiInvariant prior with an ordinary Sobel
    edge operator. It has no learnable parameters and returns a single-channel
    edge map in [0, 1]. The downstream SPIM/PCAB layers project this 1-channel
    prior to the current feature dimension before PCCA and SRG.
    """

    def __init__(self, clamp_output=True, eps=1e-6):
        super().__init__()
        self.clamp_output = clamp_output
        self.eps = float(eps)
        sobel_x = torch.tensor(
            [[-1.0, 0.0, 1.0], [-2.0, 0.0, 2.0], [-1.0, 0.0, 1.0]],
            dtype=torch.float32,
        ).view(1, 1, 3, 3)
        sobel_y = torch.tensor(
            [[-1.0, -2.0, -1.0], [0.0, 0.0, 0.0], [1.0, 2.0, 1.0]],
            dtype=torch.float32,
        ).view(1, 1, 3, 3)
        self.register_buffer('sobel_x', sobel_x)
        self.register_buffer('sobel_y', sobel_y)

    @property
    def out_channels(self):
        return 1

    @staticmethod
    def _to_gray(x):
        if x.shape[1] == 3:
            # BasicSR image tensors are RGB before entering the network.
            r, g, b = x[:, 0:1], x[:, 1:2], x[:, 2:3]
            return 0.299 * r + 0.587 * g + 0.114 * b
        if x.shape[1] == 1:
            return x
        return x.mean(dim=1, keepdim=True)

    def forward(self, x):
        gray = self._to_gray(x)
        weight_x = self.sobel_x.to(device=x.device, dtype=x.dtype)
        weight_y = self.sobel_y.to(device=x.device, dtype=x.dtype)
        grad_x = F.conv2d(gray, weight_x, padding=1)
        grad_y = F.conv2d(gray, weight_y, padding=1)
        edge = torch.sqrt(grad_x.pow(2) + grad_y.pow(2) + self.eps)

        # Per-image min-max normalization keeps the magnitude compatible with
        # the original prior branch and with externally supplied prior maps.
        b = edge.shape[0]
        edge_flat = edge.view(b, -1)
        edge_min = edge_flat.min(dim=1)[0].view(b, 1, 1, 1)
        edge_max = edge_flat.max(dim=1)[0].view(b, 1, 1, 1)
        edge = (edge - edge_min) / (edge_max - edge_min + self.eps)

        if self.clamp_output:
            edge = torch.clamp(edge, 0.0, 1.0)
        return edge

class AdaptiveMultiScaleSobelPrior(nn.Module):
    """Multi-scale adaptive Sobel structure-prior extractor.

    Compared with a fixed single-scale Sobel operator, this module computes
    Sobel responses at multiple image scales and learns a convex fusion over
    scales. The default initialization strongly favors the original-resolution
    Sobel branch, so the module starts almost equivalent to ordinary Sobel and
    can adapt during training only when other scales are beneficial.
    """

    def __init__(self, scales=(1.0, 0.5, 0.25), init_bias=8.0, clamp_output=True, eps=1e-6):
        super().__init__()
        if isinstance(scales, (int, float)):
            scales = [float(scales)]
        self.scales = tuple(float(s) for s in scales)
        if len(self.scales) == 0:
            raise ValueError('AdaptiveMultiScaleSobelPrior requires at least one scale.')
        if any(s <= 0 for s in self.scales):
            raise ValueError(f'All Sobel scales must be positive, but got {self.scales}.')

        self.clamp_output = clamp_output
        self.eps = float(eps)

        sobel_x = torch.tensor(
            [[-1.0, 0.0, 1.0], [-2.0, 0.0, 2.0], [-1.0, 0.0, 1.0]],
            dtype=torch.float32,
        ).view(1, 1, 3, 3)
        sobel_y = torch.tensor(
            [[-1.0, -2.0, -1.0], [0.0, 0.0, 0.0], [1.0, 2.0, 1.0]],
            dtype=torch.float32,
        ).view(1, 1, 3, 3)
        self.register_buffer('sobel_x', sobel_x)
        self.register_buffer('sobel_y', sobel_y)

        logits = torch.zeros(len(self.scales), dtype=torch.float32)
        logits[0] = float(init_bias)
        self.scale_logits = nn.Parameter(logits)

    @property
    def out_channels(self):
        return 1

    @staticmethod
    def _to_gray(x):
        if x.shape[1] == 3:
            # BasicSR image tensors are RGB before entering the network.
            r, g, b = x[:, 0:1], x[:, 1:2], x[:, 2:3]
            return 0.299 * r + 0.587 * g + 0.114 * b
        if x.shape[1] == 1:
            return x
        return x.mean(dim=1, keepdim=True)

    def _normalize_per_image(self, edge):
        b = edge.shape[0]
        edge_flat = edge.view(b, -1)
        edge_min = edge_flat.min(dim=1)[0].view(b, 1, 1, 1)
        edge_max = edge_flat.max(dim=1)[0].view(b, 1, 1, 1)
        return (edge - edge_min) / (edge_max - edge_min + self.eps)

    def _sobel_response(self, x):
        # x can be single-channel or multi-channel. For multi-channel inputs,
        # Sobel is applied depth-wise and then averaged to one structural map.
        c = x.shape[1]
        weight_x = self.sobel_x.to(device=x.device, dtype=x.dtype).repeat(c, 1, 1, 1)
        weight_y = self.sobel_y.to(device=x.device, dtype=x.dtype).repeat(c, 1, 1, 1)
        grad_x = F.conv2d(x, weight_x, padding=1, groups=c)
        grad_y = F.conv2d(x, weight_y, padding=1, groups=c)
        edge = torch.sqrt(grad_x.pow(2) + grad_y.pow(2) + self.eps)
        edge = edge.mean(dim=1, keepdim=True)
        return self._normalize_per_image(edge)

    def _multi_scale_sobel(self, x):
        h, w = x.shape[-2:]
        responses = []
        for scale in self.scales:
            if abs(scale - 1.0) < 1e-8:
                xs = x
            else:
                target_h = max(8, int(round(h * scale)))
                target_w = max(8, int(round(w * scale)))
                xs = F.interpolate(x, size=(target_h, target_w), mode='bilinear', align_corners=False)
            edge = self._sobel_response(xs)
            if edge.shape[-2:] != (h, w):
                edge = F.interpolate(edge, size=(h, w), mode='bilinear', align_corners=False)
                edge = self._normalize_per_image(edge)
            responses.append(edge)

        weights = torch.softmax(self.scale_logits, dim=0).to(device=x.device, dtype=x.dtype)
        prior = sum(weights[i] * responses[i] for i in range(len(responses)))
        prior = self._normalize_per_image(prior)
        if self.clamp_output:
            prior = torch.clamp(prior, 0.0, 1.0)
        return prior

    def forward(self, x):
        return self._multi_scale_sobel(self._to_gray(x))


class ColorInvariantAdaptiveMultiScaleSobelPrior(nn.Module):
    """Color-invariant enhanced adaptive multi-scale Sobel prior (CI-MASP).

    The main branch is the adaptive multi-scale Sobel prior computed from the
    luminance representation. An auxiliary color-invariant branch computes
    multi-scale Sobel responses on simple color-invariant representations
    derived from the Gaussian color model. The final prior is a learnable fusion
    of both branches. The fusion logits are initialized to favor the luminance
    Sobel branch, so CI-MASP starts almost identical to MASP/Sobel and preserves
    the strong ablation performance while allowing the color-invariant cues to
    contribute if useful.
    """

    def __init__(self,
                 scales=(1.0, 0.5, 0.25),
                 init_bias=8.0,
                 ci_fusion_init_bias=8.0,
                 clamp_output=True,
                 eps=1e-6):
        super().__init__()
        self.sobel_branch = AdaptiveMultiScaleSobelPrior(
            scales=scales,
            init_bias=init_bias,
            clamp_output=clamp_output,
            eps=eps,
        )
        self.ci_branch = AdaptiveMultiScaleSobelPrior(
            scales=scales,
            init_bias=init_bias,
            clamp_output=clamp_output,
            eps=eps,
        )
        self.clamp_output = clamp_output
        self.eps = float(eps)
        self.branch_logits = nn.Parameter(torch.tensor([float(ci_fusion_init_bias), -float(ci_fusion_init_bias)]))
        self.register_buffer(
            'gcm',
            torch.tensor(
                [[0.06, 0.63, 0.27], [0.30, 0.04, -0.35], [0.34, -0.60, 0.17]],
                dtype=torch.float32,
            ),
        )

    @property
    def out_channels(self):
        return 1

    def _normalize_per_channel(self, x):
        b = x.shape[0]
        flat = x.view(b, x.shape[1], -1)
        xmin = flat.min(dim=-1)[0].view(b, x.shape[1], 1, 1)
        xmax = flat.max(dim=-1)[0].view(b, x.shape[1], 1, 1)
        return (x - xmin) / (xmax - xmin + self.eps)

    def _color_invariant_maps(self, x):
        if x.shape[1] != 3:
            # If the input is already a prior or gray image, reuse it as the
            # auxiliary branch to keep the module robust for external s inputs.
            return x if x.shape[1] == 1 else x.mean(dim=1, keepdim=True)

        in_shape = x.shape
        flat = x.view(in_shape[0], in_shape[1], -1)
        gcm = self.gcm.to(device=x.device, dtype=x.dtype).unsqueeze(0)
        converted = torch.matmul(gcm, flat).view(in_shape[0], 3, in_shape[2], in_shape[3])
        E, El, Ell = torch.split(converted, 1, dim=1)

        # Stable color-invariant-like representations. They are not used as a
        # replacement for Sobel; instead, Sobel is computed on them and fused as
        # a small learnable auxiliary structural cue.
        denom_e = E.abs() + self.eps
        chroma_1 = El / denom_e
        chroma_2 = Ell / denom_e
        hue_like = torch.atan2(Ell, El + self.eps) / math.pi
        ci_maps = torch.cat([chroma_1, chroma_2, hue_like], dim=1)
        return self._normalize_per_channel(ci_maps)

    def _normalize_per_image(self, edge):
        b = edge.shape[0]
        edge_flat = edge.view(b, -1)
        edge_min = edge_flat.min(dim=1)[0].view(b, 1, 1, 1)
        edge_max = edge_flat.max(dim=1)[0].view(b, 1, 1, 1)
        return (edge - edge_min) / (edge_max - edge_min + self.eps)

    def forward(self, x):
        p_sobel = self.sobel_branch(x)
        p_ci = self.ci_branch(self._color_invariant_maps(x))
        weights = torch.softmax(self.branch_logits, dim=0).to(device=x.device, dtype=x.dtype)
        prior = weights[0] * p_sobel + weights[1] * p_ci
        prior = self._normalize_per_image(prior)
        if self.clamp_output:
            prior = torch.clamp(prior, 0.0, 1.0)
        return prior

