import math
from typing import Dict, Optional, Tuple

import torch
import torch.nn.functional as F


class AppearancePerturbationScheduler:
    """Training-only physically plausible appearance perturbation scheduler.

    Stages based on your custom design:
      - clean (start): keep original input (Warm-up)
      - color:         perturb color / low-frequency appearance.
                       color_mode='raw_only' directly uses the raw perturbed image;
                       color_mode='gated' blends original and raw perturbation by gate.
                       The structural prior is NOT used as a real mask here;
                       it guides the backbone through SPIM / PCAB during training.
      - clean (end):   keep original input (Cool-down / Finetune)

    Final schedule: clean -> color -> clean
    """

    def __init__(self, cfg: Optional[Dict] = None):
        cfg = cfg or {}
        self.enabled = bool(cfg.get('enabled', False))

        # 三阶段比例：clean(start) -> color -> clean(end)
        clean_start_ratio = float(cfg.get('clean_start_ratio', 0.35))
        color_ratio = float(cfg.get('color_ratio', 0.30))
        clean_end_ratio = float(cfg.get('clean_end_ratio', 0.35))

        total = max(clean_start_ratio + color_ratio + clean_end_ratio, 1e-8)
        clean_start_ratio /= total
        color_ratio /= total
        clean_end_ratio /= total

        # 计算各个阶段的结束节点
        self.clean_start_end = clean_start_ratio
        self.color_end = self.clean_start_end + color_ratio
        self.clean_end = 1.0

        self.color_cfg = cfg.get('color', {})
        self.image_gate_cfg = cfg.get('image_gate', {})

        # color_mode controls the actual training input during the color stage:
        #   gated:    final = lerp(original, raw_perturb, gate)  [old behavior]
        #   raw_only: final = raw_perturb                         [new ablation]
        #   raw:      alias of raw_only
        self.color_mode = str(cfg.get('color_mode', cfg.get('perturb_mode', 'gated'))).lower()
        if self.color_mode == 'raw':
            self.color_mode = 'raw_only'
        if self.color_mode not in {'gated', 'raw_only'}:
            raise ValueError(f"Unsupported color_mode: {self.color_mode}. Use 'gated' or 'raw_only'.")

    def get_stage(self, epoch: int, total_epochs: int) -> str:
        if not self.enabled:
            return 'clean'

        total_epochs = max(int(total_epochs), 1)
        progress = float(epoch + 1) / float(total_epochs)

        # 三阶段顺序: clean -> color -> clean
        if progress <= self.clean_start_end:
            return 'clean'
        if progress <= self.color_end:
            return 'color'
        return 'clean'

    @staticmethod
    def _rand_uniform(x: torch.Tensor, value_range, channels: Optional[int] = None):
        if value_range is None:
            value_range = [1.0, 1.0]
        low, high = float(value_range[0]), float(value_range[1])
        shape = (x.shape[0], channels if channels is not None else 1, 1, 1)
        return torch.empty(shape, device=x.device, dtype=x.dtype).uniform_(low, high)

    def _maybe_apply(self, x: torch.Tensor, op_name: str, fn, default_prob: float = 1.0) -> torch.Tensor:
        """Randomly apply one perturbation operation.

        This makes each training sample draw a different perturbation subset, rather
        than always applying all color operators in a fixed sequence. Set e.g.
        `red_attenuation_prob: 0.85` in the yaml config to control it.
        """
        prob = float(self.color_cfg.get(f'{op_name}_prob', default_prob))
        prob = min(max(prob, 0.0), 1.0)
        if prob <= 0.0:
            return x
        if prob >= 1.0 or torch.rand((), device=x.device).item() < prob:
            return fn(x)
        return x

    @staticmethod
    def _sample_int(low: int, high: int) -> int:
        if high <= low:
            return int(low)
        return int(torch.randint(low, high + 1, (1,)).item())

    @staticmethod
    def _normalize_mask(mask: torch.Tensor) -> torch.Tensor:
        flat = mask.flatten(2)
        min_val = flat.min(dim=-1, keepdim=True)[0].unsqueeze(-1)
        max_val = flat.max(dim=-1, keepdim=True)[0].unsqueeze(-1)
        return (mask - min_val) / (max_val - min_val + 1e-6)

    @staticmethod
    def _gaussian_kernel(kernel_size: int, sigma: float, channels: int, device, dtype):
        radius = kernel_size // 2
        coords = torch.arange(-radius, radius + 1, device=device, dtype=dtype)
        kernel_1d = torch.exp(-(coords ** 2) / max(2 * sigma * sigma, 1e-6))
        kernel_1d = kernel_1d / kernel_1d.sum()
        kernel_2d = torch.outer(kernel_1d, kernel_1d)
        kernel_2d = kernel_2d / kernel_2d.sum()
        return kernel_2d.view(1, 1, kernel_size, kernel_size).repeat(channels, 1, 1, 1)

    def _gaussian_blur(self, x: torch.Tensor, kernel_size: int, sigma: float) -> torch.Tensor:
        if kernel_size % 2 == 0:
            kernel_size += 1
        kernel = self._gaussian_kernel(kernel_size, sigma, x.shape[1], x.device, x.dtype)
        return F.conv2d(x, kernel, padding=kernel_size // 2, groups=x.shape[1])

    def _scale_low_frequency_amplitude(self, x: torch.Tensor) -> torch.Tensor:
        scale_range = self.color_cfg.get('low_freq_amplitude', [0.85, 1.15])
        cutoff = float(self.color_cfg.get('low_freq_cutoff', 0.12))
        cutoff = min(max(cutoff, 0.02), 0.45)

        _, _, h, w = x.shape
        w_freq = w // 2 + 1
        fy = torch.linspace(0.0, 1.0, h, device=x.device, dtype=x.dtype).view(h, 1)
        fx = torch.linspace(0.0, 1.0, w_freq, device=x.device, dtype=x.dtype).view(1, w_freq)
        radius = torch.sqrt(fy ** 2 + fx ** 2)
        low_mask = (radius <= cutoff).to(dtype=x.dtype).view(1, 1, h, w_freq)

        scale = self._rand_uniform(x, scale_range)
        freq = torch.fft.rfft2(x, dim=(-2, -1), norm='ortho')
        freq = freq * (1.0 + (scale - 1.0) * low_mask)
        return torch.fft.irfft2(freq, s=(h, w), dim=(-2, -1), norm='ortho')

    @staticmethod
    def _channel_mean(x: torch.Tensor) -> torch.Tensor:
        return x.mean(dim=(-2, -1))

    @staticmethod
    def _gray(x: torch.Tensor) -> torch.Tensor:
        return 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]

    def compute_image_gate(self, x: torch.Tensor, return_scores: bool = False):
        """Compute an image-level soft gate in [0, 1].

        Difficult images should receive larger gate values during the color
        perturbation stage, while easier images remain close to the original
        input.
        """
        cfg = self.image_gate_cfg or {}
        enabled = bool(cfg.get('enabled', False))
        if not enabled:
            gate = torch.ones((x.shape[0], 1, 1, 1), device=x.device, dtype=x.dtype)
            stats = {
                'difficulty': gate.view(-1),
                'red_deficit': gate.view(-1),
                'color_cast': gate.view(-1),
                'low_contrast': gate.view(-1),
                'haze': gate.view(-1),
                'dark': gate.view(-1),
            }
            return (gate, stats) if return_scores else gate

        eps = 1e-6
        rgb_mean = self._channel_mean(x)
        r = rgb_mean[:, 0]
        g = rgb_mean[:, 1]
        b = rgb_mean[:, 2]

        gb_mean = 0.5 * (g + b)
        red_deficit = torch.relu((gb_mean - r) / (gb_mean + eps)).clamp_(0.0, 1.0)

        rgb_center = rgb_mean.mean(dim=1, keepdim=True)
        color_cast = ((rgb_mean - rgb_center).abs().mean(dim=1) / (rgb_center.squeeze(1) + eps)).clamp_(0.0, 1.0)

        gray = self._gray(x)
        gray_std = gray.flatten(1).std(dim=1, unbiased=False)
        target_contrast = float(cfg.get('target_contrast', 0.18))
        low_contrast = torch.relu((target_contrast - gray_std) / max(target_contrast, eps)).clamp_(0.0, 1.0)

        x_max = x.max(dim=1, keepdim=True)[0]
        x_min = x.min(dim=1, keepdim=True)[0]
        saturation = ((x_max - x_min) / (x_max + eps)).mean(dim=(-2, -1)).squeeze(1)
        target_saturation = float(cfg.get('target_saturation', 0.20))
        haze = torch.relu((target_saturation - saturation) / max(target_saturation, eps)).clamp_(0.0, 1.0)

        dark_threshold = float(cfg.get('dark_threshold', 0.35))
        dark_ratio = (gray < dark_threshold).float().mean(dim=(-2, -1)).squeeze(1)
        target_dark_ratio = float(cfg.get('target_dark_ratio', 0.60))
        dark = (dark_ratio / max(target_dark_ratio, eps)).clamp_(0.0, 1.0)

        default_weights = {
            'red_deficit': 0.30,
            'color_cast': 0.25,
            'low_contrast': 0.20,
            'haze': 0.15,
            'dark': 0.10,
        }
        weights = default_weights.copy()
        weights.update(cfg.get('weights', {}))
        weight_sum = max(sum(float(v) for v in weights.values()), eps)

        difficulty = (
            float(weights['red_deficit']) * red_deficit
            + float(weights['color_cast']) * color_cast
            + float(weights['low_contrast']) * low_contrast
            + float(weights['haze']) * haze
            + float(weights['dark']) * dark
        ) / weight_sum

        gamma = float(cfg.get('gamma', 1.0))
        gamma = max(gamma, 1e-6)
        difficulty = difficulty.clamp(0.0, 1.0).pow(gamma)

        min_gate = float(cfg.get('min_gate', 0.0))
        max_gate = float(cfg.get('max_gate', 1.0))
        min_gate = min(max(min_gate, 0.0), 1.0)
        max_gate = min(max(max_gate, min_gate), 1.0)
        difficulty = difficulty * (max_gate - min_gate) + min_gate
        difficulty = difficulty.clamp(min_gate, max_gate)

        gate = difficulty.view(-1, 1, 1, 1)
        stats = {
            'difficulty': difficulty,
            'red_deficit': red_deficit,
            'color_cast': color_cast,
            'low_contrast': low_contrast,
            'haze': haze,
            'dark': dark,
        }
        return (gate, stats) if return_scores else gate

    def _spatial_lowfreq_mask(self, x: torch.Tensor) -> torch.Tensor:
        b, _, h, w = x.shape
        base = torch.rand((b, 1, h, w), device=x.device, dtype=x.dtype)
        k = max(5, int(min(h, w) * 0.08) | 1)
        sigma = max(float(k) / 6.0, 1.0)
        mask = self._gaussian_blur(base, k, sigma)
        return self._normalize_mask(mask)

    def _compress_global_contrast(self, x: torch.Tensor) -> torch.Tensor:
        strength = self._rand_uniform(x, self.color_cfg.get('contrast_compress', [0.0, 0.0]))
        gray = self._gray(x)
        center = gray.mean(dim=(-2, -1), keepdim=True).repeat(1, x.shape[1], 1, 1)
        return center + (x - center) * (1.0 - strength)

    def _compress_local_contrast(self, x: torch.Tensor) -> torch.Tensor:
        strength = self._rand_uniform(x, self.color_cfg.get('local_contrast_compress', [0.0, 0.0]))
        local_mean = self._gaussian_blur(x, 9, 2.0)
        return local_mean + (x - local_mean) * (1.0 - strength)

    def _detail_blur(self, x: torch.Tensor) -> torch.Tensor:
        strength = self._rand_uniform(x, self.color_cfg.get('detail_blur_strength', [0.0, 0.0]))
        sigma_range = self.color_cfg.get('blur_sigma', [0.6, 1.6])
        sigma = self._rand_uniform(x, sigma_range)
        outs = []
        for i in range(x.shape[0]):
            blur = self._gaussian_blur(x[i:i+1], 7, float(sigma[i, 0, 0, 0].item()))
            outs.append(torch.lerp(x[i:i+1], blur, strength[i:i+1]))
        return torch.cat(outs, dim=0)

    def _apply_spatial_veil(self, x: torch.Tensor) -> torch.Tensor:
        strength = self._rand_uniform(x, self.color_cfg.get('spatial_veil_strength', [0.0, 0.0]))
        veil = strength * self._spatial_lowfreq_mask(x)
        fog_rgb = torch.cat([
            self._rand_uniform(x, self.color_cfg.get('fog_rgb_r', [0.20, 0.45])),
            self._rand_uniform(x, self.color_cfg.get('fog_rgb_g', [0.45, 0.70])),
            self._rand_uniform(x, self.color_cfg.get('fog_rgb_b', [0.55, 0.85])),
        ], dim=1)
        return x * (1.0 - veil) + fog_rgb * veil

    def _color_perturb_only(self, x: torch.Tensor) -> torch.Tensor:
        out = x.clone()

        # Random subset + wider sampling ranges. This produces the raw perturbed
        # image x_i^raw used by the raw_only ablation.
        def red_op(t):
            red_scale = self._rand_uniform(t, self.color_cfg.get('red_attenuation', [0.55, 0.95]))
            y = t.clone()
            y[:, 0:1] = y[:, 0:1] * red_scale
            return y

        def cast_op(t):
            color_cast = self._rand_uniform(t, self.color_cfg.get('color_cast', [0.78, 1.25]), channels=3)
            return t * color_cast

        def fog_op(t):
            fog_strength = self._rand_uniform(t, self.color_cfg.get('fog_strength', [0.04, 0.22]))
            fog_rgb = torch.cat([
                self._rand_uniform(t, self.color_cfg.get('fog_rgb_r', [0.12, 0.46])),
                self._rand_uniform(t, self.color_cfg.get('fog_rgb_g', [0.38, 0.76])),
                self._rand_uniform(t, self.color_cfg.get('fog_rgb_b', [0.52, 0.95])),
            ], dim=1)
            return t * (1.0 - fog_strength) + fog_rgb * fog_strength

        out = self._maybe_apply(out, 'red_attenuation', red_op, default_prob=0.90)
        out = self._maybe_apply(out, 'low_freq_amplitude', self._scale_low_frequency_amplitude, default_prob=0.85)
        out = self._maybe_apply(out, 'color_cast', cast_op, default_prob=0.90)
        out = self._maybe_apply(out, 'contrast_compress', self._compress_global_contrast, default_prob=0.80)
        out = self._maybe_apply(out, 'local_contrast_compress', self._compress_local_contrast, default_prob=0.80)
        out = self._maybe_apply(out, 'detail_blur', self._detail_blur, default_prob=0.65)
        out = self._maybe_apply(out, 'fog', fog_op, default_prob=0.85)
        out = self._maybe_apply(out, 'spatial_veil', self._apply_spatial_veil, default_prob=0.80)
        return torch.clamp(out, 0.0, 1.0)

    def apply_color_raw_only(self, x: torch.Tensor) -> torch.Tensor:
        """Directly use the raw random perturbation as training input."""
        return self._color_perturb_only(x)

    def apply_color_with_gate(self, x: torch.Tensor, gate: torch.Tensor) -> torch.Tensor:
        gate = gate.clamp(0.0, 1.0).to(device=x.device, dtype=x.dtype)
        if gate.ndim == 1:
            gate = gate.view(-1, 1, 1, 1)
        x_aug = self._color_perturb_only(x)
        return torch.lerp(x, x_aug, gate)

    def apply_color(self, x: torch.Tensor, guide_x: Optional[torch.Tensor] = None, return_gate: bool = False):
        if self.color_mode == 'raw_only':
            out = self.apply_color_raw_only(x)
            gate = torch.ones((x.shape[0], 1, 1, 1), device=x.device, dtype=x.dtype)
            gate_stats = {'raw_only': gate.view(-1)}
            if return_gate:
                return out, gate, gate_stats
            return out

        guide_source = x if guide_x is None else guide_x
        gate, gate_stats = self.compute_image_gate(guide_source, return_scores=True)
        out = self.apply_color_with_gate(x, gate)

        if return_gate:
            return out, gate, gate_stats
        return out


# Backward-compatible alias for existing training code.
TrainInputScheduler = AppearancePerturbationScheduler
